﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
   public class KhoDAO
    {
        private static KhoDAO instance;
        public static KhoDAO Instace
        {
            get
            {
                if (instance == null) return new KhoDAO();
                return instance;
            }
        }
    }
}
