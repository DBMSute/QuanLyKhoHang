﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using System.Data;
using System.Data.SqlClient;
namespace DAO
{
   public class KhoDAO
    {
        private static KhoDAO instance;
        public static KhoDAO Instace
        {
            get
            {
                if (instance == null) return new KhoDAO();
                return instance;
            }
        }
       public List<Kho> loadData()
        {
            List<Kho> khoDao = new List<Kho>();
            string str = "select * from Kho";
            DataTable data = DataConn.Instance.ExecuteQuery(str);
            foreach (DataRow item in data.Rows)
            {
                int id = (int)item["id"];
                string ten = item["tenKho"].ToString();
                string diaChi = item["diachi"].ToString();
                bool tinhTrang = (bool)item["tinhtrang"];
                Kho kh = new Kho(id, ten,diaChi,tinhTrang);
                khoDao.Add(kh);
            }
            return khoDao;
        }
       //public List<Hang> Timkiem(string strTimKiem)
       //{
          
       //    return khoDao;
       //}
       
       
       
       public bool themKho(string id, string ten, string diaChi,string taiKhoan, bool tinhTrang)
       {
         
           return true;
       }
       public bool xoaKho(string id)
       {
           
          
           return true;
       }
       public bool suaKho(string id, string ten, string diaChi, string taiKhoan, bool tinhTrang)
       {
          
           return true;
       }
    }
}
