﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
   public class NhaCCDAO
    {
       private static NhaCCDAO instance;
       public static NhaCCDAO Instace
        {
            get
            {
                if (instance == null) return new NhaCCDAO();
                return instance;
            }
        }
    }
}
