﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
   public class TaiKhoan
    {
        public string id, tenTk,ten, passWd, createday,hovatendem,ngaysinh,diachi,lastlogin;
        byte[] avt;
        public int pers;
        public bool tinhTrang;

       
      
      
        public string ID
        {
            get { return id; }
            set { id = value; }
        }
        public string TENTK
        {
            get { return tenTk; }
            set { tenTk = value; }
        }
        public string PASSWD
        {
            get { return passWd; }
            set { passWd = value; }
        }
        public string HOVATENDEM
        {
            get { return hovatendem; }
            set { hovatendem = value; }
        } 
       public string TEN
        {
            get { return ten; }
            set { ten = value; }
        }

      
        public string DIACHI
        {
            get { return diachi; }
            set { diachi = value; }
        }
      
        public string CREATEDAY
        {
            get { return createday; }
            set { createday = value; }
        }
        public int PERS
        {
            get { return pers; }
            set { pers = value; }
        }
        public bool TINHTRANG
        {
            get { return tinhTrang; }
            set { tinhTrang = value; }
        }
        public string LASTLOGIN
        {
            get { return lastlogin; }
            set { lastlogin = value; }
        }
    
    
       
       public TaiKhoan(string id, string tenTk, string passWd,string ten,string hovatendem,
            string ngaysinh,string diachi,
             string lastlogin,string createday,
            int pers, bool tinhTrang)
        {
            this.ten = ten;
            this.lastlogin = lastlogin;
            this.createday = createday;
            this.hovatendem = hovatendem;
            this.ngaysinh = ngaysinh;
            this.diachi = diachi;
            this.id = id;
            this.tenTk = tenTk;
            this.passWd = passWd;   
            this.pers = pers;
            this.tinhTrang = tinhTrang;
        }
       public TaiKhoan( string tenTk, string passWd, string ten, string hovatendem,
           string ngaysinh, string diachi,
            string lastlogin, string createday,
           int pers, bool tinhTrang)
        {
            this.ten = ten;
            this.lastlogin = lastlogin;
            this.createday = createday;
            this.hovatendem = hovatendem;
            this.ngaysinh = ngaysinh;
            this.diachi = diachi;
            this.tenTk = tenTk;
            this.passWd = passWd;
            this.pers = pers;
            this.tinhTrang = tinhTrang;
        }
        public TaiKhoan()
        {

        }

    }
}
