﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DAO
{
   public class NhaCungCapDAO
    {
        private static NhaCungCapDAO instance;
        public static NhaCungCapDAO Instance
        {
            get
            {
                if (instance == null) return new NhaCungCapDAO();
                return instance;
            }
        }
        public List<DAO.NhaCungCap> loadData()
        {
            List<DAO.NhaCungCap> lNcc = new List<DAO.NhaCungCap>();
            string str = "select * from NhaCungCap";
            DataTable data = DataConn.Instance.ExecuteQuery(str);
            foreach (DataRow item in data.Rows)
            {
                string id = item["id"].ToString();
                string ten = item["ten"].ToString();
                string diaChi = item["dchi"].ToString();
                string sdt = item["sdt"].ToString();
                string qGia = item["qGia"].ToString();
                DAO.NhaCungCap ncc = new DAO.NhaCungCap(id, ten, diaChi, sdt, qGia);
                lNcc.Add(ncc);
            }
            return lNcc;
        }
        public List<DAO.NhaCungCap> timKiem(string strTimKiem)
        {
            List<DAO.NhaCungCap> lNcc = new List<DAO.NhaCungCap>();
            string str = "select * from NhaCungCap where id like N'%" + strTimKiem.Trim() + "%' or ten like N'%" + strTimKiem.Trim()
               + "%' or dchi like N'%" + strTimKiem.Trim() + "%'";
            DataTable data = DataConn.Instance.ExecuteQuery(str);
            foreach (DataRow item in data.Rows)
            {
                string id = item["id"].ToString();
                string ten = item["ten"].ToString();
                string diaChi = item["dchi"].ToString();
                string sdt = item["sdt"].ToString();
                string qGia = item["qGia"].ToString();
                DAO.NhaCungCap ncc = new DAO.NhaCungCap(id, ten, diaChi, sdt, qGia);
                lNcc.Add(ncc);
            }
            return lNcc;
        }
       public List<DAO.NhaCungCap> Them()
        {
            List<DAO.NhaCungCap> lNcc = new List<DAO.NhaCungCap>();
            DAO.NhaCungCap n = new DAO.NhaCungCap();
            lNcc.Add(n);
            string str = "select * from NhaCungCap";
            DataTable data = DataConn.Instance.ExecuteQuery(str);
            foreach (DataRow item in data.Rows)
            {
                string id = item["id"].ToString();
                string ten = item["ten"].ToString();
                string diaChi = item["dchi"].ToString();
                string sdt = item["sdt"].ToString();
                string qGia = item["qGia"].ToString();
                DAO.NhaCungCap ncc = new DAO.NhaCungCap(id, ten, diaChi, sdt, qGia);
                lNcc.Add(ncc);
            }
            return lNcc;
        }
       public void LuuThem(List<DAO.NhaCungCap> lNcc)
       {
           string str = "exec sp_Insert_NhaCungCap @ten=N'" + lNcc[0].ten + "',@dchi=N'" + 
               lNcc[0].diaChi + "',@sdt='" + lNcc[0].soDT +
               "',@qGia=N'" + lNcc[0].qGia+"'";
           DataConn.Instance.ExecuteQuery(str);
       }
       public void LuuSua(List<DAO.NhaCungCap> lNcc)
       {
           for(int i=0;i<lNcc.Count;i++)
           {
               string str = "exec sp_Update_NhaCungCap @id='" + lNcc[i].id + "' ,@ten=N'" + lNcc[i].ten + "',@dchi=N'" +
               lNcc[i].diaChi + "',@sdt='" + lNcc[i].soDT +
               "',@qGia=N'" + lNcc[i].qGia+"'";
               DataConn.Instance.ExecuteQuery(str);
           }
       }
       public void Xoa(string id)
       {
           string str = "delete from  NhaCungCap where id='" + id + "'";
           DataConn.Instance.ExecuteQuery(str);
       }
    }
}
