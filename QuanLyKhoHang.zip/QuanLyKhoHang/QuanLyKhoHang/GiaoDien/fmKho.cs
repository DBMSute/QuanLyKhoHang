﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyKhoHang.GiaoDien
{
    public partial class fmKhoHang : Form
    {
        public fmKhoHang()
        {
            InitializeComponent();
        }

    
        private void tm1_Tick(object sender, EventArgs e)
        {

        }



        //Xem hang hoac kho
        //kho      
        private void lbkho_Click(object sender, EventArgs e)
        {
            pcbXemKho.BackColor = Color.FromArgb(254, 141, 0);
            lbkho.BackColor = Color.FromArgb(254, 141, 0);
            //
            pcbXemHang.BackColor = Color.FromArgb(157, 87, 2);
            lbHang.BackColor = Color.FromArgb(157, 87, 2);
        }
        private void pcbXemKho_Click(object sender, EventArgs e)
        {
            pcbXemKho.BackColor = Color.FromArgb(254, 141, 0);
            lbkho.BackColor = Color.FromArgb(254, 141, 0);
            //
            pcbXemHang.BackColor = Color.FromArgb(157, 87, 2);
            lbHang.BackColor = Color.FromArgb(157, 87, 2);    
        }     
        // hang      
        private void lbHang_Click(object sender, EventArgs e)
        {
            pcbXemHang.BackColor = Color.FromArgb(254, 141, 0);
            lbHang.BackColor = Color.FromArgb(254, 141, 0);
            //
            pcbXemKho.BackColor = Color.FromArgb(157, 87, 2);
            lbkho.BackColor = Color.FromArgb(157, 87, 2);
        }
        private void pcbXemHang_Click(object sender, EventArgs e)
        {
            pcbXemHang.BackColor = Color.FromArgb(254, 141, 0);
            lbHang.BackColor = Color.FromArgb(254, 141, 0);
            //
            pcbXemKho.BackColor = Color.FromArgb(157, 87, 2);
            lbkho.BackColor = Color.FromArgb(157, 87, 2);
        }
        //


        //Tim Kiem
        private void pcbTimKiem_Click(object sender, EventArgs e)
        {

        }
        private void lbTimKiem_Click(object sender, EventArgs e)
        {

        }
        private void pcbTimKiem_MouseHover(object sender, EventArgs e)
        {
            pcbTimKiem.BackColor = Color.FromArgb(103, 180, 30);
            lbTimKiem.BackColor = Color.FromArgb(103, 180, 30);
        }
        private void pcbTimKiem_MouseLeave(object sender, EventArgs e)
        {
            pcbTimKiem.BackColor = Color.FromArgb(15,114,15);
            lbTimKiem.BackColor = Color.FromArgb(15, 114, 15);
        }
        private void lbTimKiem_MouseHover(object sender, EventArgs e)
        {
            pcbTimKiem.BackColor = Color.FromArgb(103, 180, 30);
            lbTimKiem.BackColor = Color.FromArgb(103, 180, 30);
        }
        private void lbTimKiem_MouseLeave(object sender, EventArgs e)
        {
            pcbTimKiem.BackColor = Color.FromArgb(15, 114, 15);
        }


        //Them
        private void pcbThem_Click(object sender, EventArgs e)
        {

        }
        private void lbThem_Click(object sender, EventArgs e)
        {

        }
        private void lbThem_MouseHover(object sender, EventArgs e)
        {
            pcbThem.BackColor = Color.FromArgb(0, 188, 242);
            lbThem.BackColor = Color.FromArgb(0, 188, 242);
        }
        private void pcbThem_MouseHover(object sender, EventArgs e)
        {
            pcbThem.BackColor = Color.FromArgb(0, 188, 242);
            lbThem.BackColor = Color.FromArgb(0, 188, 242);
        }
        private void pcbThem_MouseLeave(object sender, EventArgs e)
        {
            pcbThem.BackColor = Color.FromArgb(0, 120, 215);
            lbThem.BackColor = Color.FromArgb(0, 120, 215);
        }


        //Xoa
        private void pcbXoa_Click(object sender, EventArgs e)
        {

        }
        private void lbXoa_Click(object sender, EventArgs e)
        {

        }
        private void lbXoa_MouseHover(object sender, EventArgs e)
        {
            pcbXoa.BackColor = Color.FromArgb(207, 97, 45);
            lbXoa.BackColor = Color.FromArgb(207, 97, 45);
        }
        private void pcbXoa_MouseHover(object sender, EventArgs e)
        {
            pcbXoa.BackColor = Color.FromArgb(207, 97, 45);
            lbXoa.BackColor = Color.FromArgb(207, 97, 45);
        }
        private void pcbXoa_MouseLeave(object sender, EventArgs e)
        {
            pcbXoa.BackColor = Color.FromArgb(216, 59, 1);
            lbXoa.BackColor = Color.FromArgb(216, 59, 1);
        }



        //Sua
        private void pcbSua_Click(object sender, EventArgs e)
        {

        }
        private void lbSua_Click(object sender, EventArgs e)
        {

        }
        private void lbSua_MouseHover(object sender, EventArgs e)
        {
            pcbSua.BackColor = Color.FromArgb(80, 138, 25);
            lbSua.BackColor = Color.FromArgb(80, 138, 25);
        }
        private void pcbSua_MouseHover(object sender, EventArgs e)
        {
            pcbSua.BackColor = Color.FromArgb(80, 138, 25);
            lbSua.BackColor = Color.FromArgb(80, 138, 25);
        }
        private void pcbSua_MouseLeave(object sender, EventArgs e)
        {
            pcbSua.BackColor = Color.FromArgb(10, 74, 10);
            lbSua.BackColor = Color.FromArgb(10, 74, 10);
        }



        //In
        private void pcbIn_Click(object sender, EventArgs e)
        {

        }
        private void lbIn_Click(object sender, EventArgs e)
        {

        }
        private void lbIn_MouseHover(object sender, EventArgs e)
        {
            pcbIn.BackColor = Color.FromArgb(80, 80, 80);
            lbIn.BackColor = Color.FromArgb(80, 80, 80);
        }
        private void pcbIn_MouseHover(object sender, EventArgs e)
        {
            pcbIn.BackColor = Color.FromArgb(80, 80, 80);
            lbIn.BackColor = Color.FromArgb(80, 80, 80);
        }
        private void pcbIn_MouseLeave(object sender, EventArgs e)
        {
            pcbIn.BackColor = Color.FromArgb(24, 24, 24);
            lbIn.BackColor = Color.FromArgb(24, 24, 24);
        }
       



        //Thong ke
        private void pcbThongKe_Click(object sender, EventArgs e)
        {

        }
        private void lbThongKe_Click(object sender, EventArgs e)
        {

        }
        private void lbThongKe_MouseHover(object sender, EventArgs e)
        {
            pcbThongKe.BackColor = Color.FromArgb(195, 107, 0);
            lbThongKe.BackColor = Color.FromArgb(195, 107, 0);
        }
        private void pcbThongKe_MouseHover(object sender, EventArgs e)
        {
            pcbThongKe.BackColor = Color.FromArgb(195, 107, 0);
            lbThongKe.BackColor = Color.FromArgb(195, 107, 0);
        }
        private void pcbThongKe_MouseLeave(object sender, EventArgs e)
        {
            pcbThongKe.BackColor = Color.FromArgb(154, 84, 0);
            lbThongKe.BackColor = Color.FromArgb(154, 84, 0);
        }


        //Quyen Truy Cap
        private void pcbChinhQuyenTruyCap_Click(object sender, EventArgs e)
        {

        }
        private void lbChinhQuyenTruyCap_Click(object sender, EventArgs e)
        {

        }
        private void lbChinhQuyenTruyCap_MouseHover(object sender, EventArgs e)
        {
            pcbChinhQuyenTruyCap.BackColor = Color.FromArgb(75, 56, 120);
            lbChinhQuyenTruyCap.BackColor = Color.FromArgb(75, 56, 120);
        }
        private void pcbChinhQuyenTruyCap_MouseHover(object sender, EventArgs e)
        {
            pcbChinhQuyenTruyCap.BackColor = Color.FromArgb(75, 56, 120);
            lbChinhQuyenTruyCap.BackColor = Color.FromArgb(75, 56, 120);
        }
        private void pcbChinhQuyenTruyCap_MouseLeave(object sender, EventArgs e)
        {
            pcbChinhQuyenTruyCap.BackColor = Color.FromArgb(52, 16, 60);
            lbChinhQuyenTruyCap.BackColor = Color.FromArgb(52, 16, 60);
        }

        

       

  
   
     
    }
}
