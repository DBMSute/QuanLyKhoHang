﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyKhoHang.GiaoDien
{
    public partial class fmKhoHang : Form
    {
        public fmKhoHang()
        {
            InitializeComponent();
        }

    
        private void tm1_Tick(object sender, EventArgs e)
        {

        }

        private void pcbXemKho_Click(object sender, EventArgs e)
        {
            pcbXemKho.BackColor = Color.FromArgb(254, 141, 0);
            pcbXemKhoHang.BackColor = Color.FromArgb(157, 87, 2);
        }

        private void pcbXemKhoHang_Click(object sender, EventArgs e)
        {
            pcbXemKhoHang.BackColor = Color.FromArgb(254, 141, 0);
            pcbXemKho.BackColor = Color.FromArgb(157, 87, 2);
        }

        private void pcbTimKiem_Click(object sender, EventArgs e)
        {

        }

        private void pcbTimKiem_MouseHover(object sender, EventArgs e)
        {
            pcbTimKiem.BackColor = Color.FromArgb(103, 180, 30);
        }

        private void pcbTimKiem_MouseLeave(object sender, EventArgs e)
        {
            pcbTimKiem.BackColor = Color.FromArgb(15,114,15);
        }

        private void pcbThem_Click(object sender, EventArgs e)
        {

        }

        private void pcbThem_MouseHover(object sender, EventArgs e)
        {
            pcbThem.BackColor = Color.FromArgb(0, 188, 242);
        }

        private void pcbThem_MouseLeave(object sender, EventArgs e)
        {
            pcbThem.BackColor = Color.FromArgb(0, 120, 215);
        }

        private void pcbXoa_Click(object sender, EventArgs e)
        {

        }

        private void pcbXoa_MouseHover(object sender, EventArgs e)
        {
            pcbXoa.BackColor = Color.FromArgb(207, 97, 45);
        }

        private void pcbXoa_MouseLeave(object sender, EventArgs e)
        {
            pcbXoa.BackColor = Color.FromArgb(216, 59, 1);
        }

        private void pcbSua_Click(object sender, EventArgs e)
        {

        }

        private void pcbSua_MouseHover(object sender, EventArgs e)
        {
            pcbSua.BackColor = Color.FromArgb(80, 138, 25);
        }

        private void pcbSua_MouseLeave(object sender, EventArgs e)
        {
            pcbSua.BackColor = Color.FromArgb(10, 74, 10);
        }

        private void pcbIn_Click(object sender, EventArgs e)
        {

        }

        private void pcbIn_MouseHover(object sender, EventArgs e)
        {
            pcbIn.BackColor = Color.FromArgb(80, 80, 80);
        }

        private void pcbIn_MouseLeave(object sender, EventArgs e)
        {
            pcbIn.BackColor = Color.FromArgb(24, 24, 24);
        }

        private void pcbThongKe_Click(object sender, EventArgs e)
        {

        }

        private void pcbThongKe_MouseHover(object sender, EventArgs e)
        {
            pcbThongKe.BackColor = Color.FromArgb(195, 107, 0);
        }

        private void pcbThongKe_MouseLeave(object sender, EventArgs e)
        {
            pcbThongKe.BackColor = Color.FromArgb(154, 84, 0);
        }

        private void pcbChinhQuyenTruyCap_Click(object sender, EventArgs e)
        {

        }

        private void pcbChinhQuyenTruyCap_MouseHover(object sender, EventArgs e)
        {
            pcbChinhQuyenTruyCap.BackColor = Color.FromArgb(75, 56, 120);
        }

        private void pcbChinhQuyenTruyCap_MouseLeave(object sender, EventArgs e)
        {
            pcbChinhQuyenTruyCap.BackColor = Color.FromArgb(52, 16, 60);
        }
    }
}
