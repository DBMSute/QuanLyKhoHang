﻿namespace QuanLyKhoHang.GiaoDien
{
    partial class fmKhoHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pcbThongKe = new System.Windows.Forms.PictureBox();
            this.pcbChinhQuyenTruyCap = new System.Windows.Forms.PictureBox();
            this.pcbXemKho = new System.Windows.Forms.PictureBox();
            this.pcbXemKhoHang = new System.Windows.Forms.PictureBox();
            this.pcbTimKiem = new System.Windows.Forms.PictureBox();
            this.pcbIn = new System.Windows.Forms.PictureBox();
            this.pcbSua = new System.Windows.Forms.PictureBox();
            this.pcbXoa = new System.Windows.Forms.PictureBox();
            this.pcbThem = new System.Windows.Forms.PictureBox();
            this.dtgvKho = new System.Windows.Forms.DataGridView();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.tm1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbThongKe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbChinhQuyenTruyCap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbXemKho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbXemKhoHang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbTimKiem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbXoa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbThem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKho)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.panel1.Controls.Add(this.pcbThongKe);
            this.panel1.Controls.Add(this.pcbChinhQuyenTruyCap);
            this.panel1.Controls.Add(this.pcbXemKho);
            this.panel1.Controls.Add(this.pcbXemKhoHang);
            this.panel1.Controls.Add(this.pcbTimKiem);
            this.panel1.Controls.Add(this.pcbIn);
            this.panel1.Controls.Add(this.pcbSua);
            this.panel1.Controls.Add(this.pcbXoa);
            this.panel1.Controls.Add(this.pcbThem);
            this.panel1.Controls.Add(this.dtgvKho);
            this.panel1.Controls.Add(this.txtTimKiem);
            this.panel1.Location = new System.Drawing.Point(-1, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(931, 551);
            this.panel1.TabIndex = 0;
            // 
            // pcbThongKe
            // 
            this.pcbThongKe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.pcbThongKe.Location = new System.Drawing.Point(18, 233);
            this.pcbThongKe.Name = "pcbThongKe";
            this.pcbThongKe.Size = new System.Drawing.Size(135, 100);
            this.pcbThongKe.TabIndex = 10;
            this.pcbThongKe.TabStop = false;
            this.pcbThongKe.Click += new System.EventHandler(this.pcbThongKe_Click);
            this.pcbThongKe.MouseLeave += new System.EventHandler(this.pcbThongKe_MouseLeave);
            this.pcbThongKe.MouseHover += new System.EventHandler(this.pcbThongKe_MouseHover);
            // 
            // pcbChinhQuyenTruyCap
            // 
            this.pcbChinhQuyenTruyCap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(16)))), ((int)(((byte)(60)))));
            this.pcbChinhQuyenTruyCap.Location = new System.Drawing.Point(18, 373);
            this.pcbChinhQuyenTruyCap.Name = "pcbChinhQuyenTruyCap";
            this.pcbChinhQuyenTruyCap.Size = new System.Drawing.Size(135, 100);
            this.pcbChinhQuyenTruyCap.TabIndex = 9;
            this.pcbChinhQuyenTruyCap.TabStop = false;
            this.pcbChinhQuyenTruyCap.Click += new System.EventHandler(this.pcbChinhQuyenTruyCap_Click);
            this.pcbChinhQuyenTruyCap.MouseLeave += new System.EventHandler(this.pcbChinhQuyenTruyCap_MouseLeave);
            this.pcbChinhQuyenTruyCap.MouseHover += new System.EventHandler(this.pcbChinhQuyenTruyCap_MouseHover);
            // 
            // pcbXemKho
            // 
            this.pcbXemKho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(87)))), ((int)(((byte)(2)))));
            this.pcbXemKho.Location = new System.Drawing.Point(88, 31);
            this.pcbXemKho.Name = "pcbXemKho";
            this.pcbXemKho.Size = new System.Drawing.Size(65, 30);
            this.pcbXemKho.TabIndex = 8;
            this.pcbXemKho.TabStop = false;
            this.pcbXemKho.Click += new System.EventHandler(this.pcbXemKho_Click);
            // 
            // pcbXemKhoHang
            // 
            this.pcbXemKhoHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(141)))), ((int)(((byte)(0)))));
            this.pcbXemKhoHang.Location = new System.Drawing.Point(20, 31);
            this.pcbXemKhoHang.Name = "pcbXemKhoHang";
            this.pcbXemKhoHang.Size = new System.Drawing.Size(65, 30);
            this.pcbXemKhoHang.TabIndex = 7;
            this.pcbXemKhoHang.TabStop = false;
            this.pcbXemKhoHang.Click += new System.EventHandler(this.pcbXemKhoHang_Click);
            // 
            // pcbTimKiem
            // 
            this.pcbTimKiem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(114)))), ((int)(((byte)(15)))));
            this.pcbTimKiem.Location = new System.Drawing.Point(766, 31);
            this.pcbTimKiem.Name = "pcbTimKiem";
            this.pcbTimKiem.Size = new System.Drawing.Size(130, 30);
            this.pcbTimKiem.TabIndex = 6;
            this.pcbTimKiem.TabStop = false;
            this.pcbTimKiem.Click += new System.EventHandler(this.pcbTimKiem_Click);
            this.pcbTimKiem.MouseLeave += new System.EventHandler(this.pcbTimKiem_MouseLeave);
            this.pcbTimKiem.MouseHover += new System.EventHandler(this.pcbTimKiem_MouseHover);
            // 
            // pcbIn
            // 
            this.pcbIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.pcbIn.Location = new System.Drawing.Point(93, 160);
            this.pcbIn.Name = "pcbIn";
            this.pcbIn.Size = new System.Drawing.Size(60, 50);
            this.pcbIn.TabIndex = 5;
            this.pcbIn.TabStop = false;
            this.pcbIn.Click += new System.EventHandler(this.pcbIn_Click);
            this.pcbIn.MouseLeave += new System.EventHandler(this.pcbIn_MouseLeave);
            this.pcbIn.MouseHover += new System.EventHandler(this.pcbIn_MouseHover);
            // 
            // pcbSua
            // 
            this.pcbSua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(74)))), ((int)(((byte)(10)))));
            this.pcbSua.Location = new System.Drawing.Point(20, 160);
            this.pcbSua.Name = "pcbSua";
            this.pcbSua.Size = new System.Drawing.Size(60, 50);
            this.pcbSua.TabIndex = 4;
            this.pcbSua.TabStop = false;
            this.pcbSua.Click += new System.EventHandler(this.pcbSua_Click);
            this.pcbSua.MouseLeave += new System.EventHandler(this.pcbSua_MouseLeave);
            this.pcbSua.MouseHover += new System.EventHandler(this.pcbSua_MouseHover);
            // 
            // pcbXoa
            // 
            this.pcbXoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(59)))), ((int)(((byte)(1)))));
            this.pcbXoa.Location = new System.Drawing.Point(93, 94);
            this.pcbXoa.Name = "pcbXoa";
            this.pcbXoa.Size = new System.Drawing.Size(60, 50);
            this.pcbXoa.TabIndex = 3;
            this.pcbXoa.TabStop = false;
            this.pcbXoa.Click += new System.EventHandler(this.pcbXoa_Click);
            this.pcbXoa.MouseLeave += new System.EventHandler(this.pcbXoa_MouseLeave);
            this.pcbXoa.MouseHover += new System.EventHandler(this.pcbXoa_MouseHover);
            // 
            // pcbThem
            // 
            this.pcbThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(215)))));
            this.pcbThem.Location = new System.Drawing.Point(20, 94);
            this.pcbThem.Name = "pcbThem";
            this.pcbThem.Size = new System.Drawing.Size(60, 50);
            this.pcbThem.TabIndex = 2;
            this.pcbThem.TabStop = false;
            this.pcbThem.Click += new System.EventHandler(this.pcbThem_Click);
            this.pcbThem.MouseLeave += new System.EventHandler(this.pcbThem_MouseLeave);
            this.pcbThem.MouseHover += new System.EventHandler(this.pcbThem_MouseHover);
            // 
            // dtgvKho
            // 
            this.dtgvKho.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(239)))), ((int)(((byte)(237)))));
            this.dtgvKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvKho.Location = new System.Drawing.Point(182, 96);
            this.dtgvKho.Name = "dtgvKho";
            this.dtgvKho.Size = new System.Drawing.Size(725, 407);
            this.dtgvKho.TabIndex = 1;
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKiem.Location = new System.Drawing.Point(305, 31);
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(427, 31);
            this.txtTimKiem.TabIndex = 0;
            // 
            // tm1
            // 
            this.tm1.Tick += new System.EventHandler(this.tm1_Tick);
            // 
            // fmKhoHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.ClientSize = new System.Drawing.Size(929, 529);
            this.Controls.Add(this.panel1);
            this.Name = "fmKhoHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fmKhoHang";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcbThongKe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbChinhQuyenTruyCap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbXemKho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbXemKhoHang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbTimKiem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbSua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbXoa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbThem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvKho)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dtgvKho;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.PictureBox pcbChinhQuyenTruyCap;
        private System.Windows.Forms.PictureBox pcbXemKho;
        private System.Windows.Forms.PictureBox pcbXemKhoHang;
        private System.Windows.Forms.PictureBox pcbTimKiem;
        private System.Windows.Forms.PictureBox pcbIn;
        private System.Windows.Forms.PictureBox pcbSua;
        private System.Windows.Forms.PictureBox pcbXoa;
        private System.Windows.Forms.PictureBox pcbThem;
        private System.Windows.Forms.PictureBox pcbThongKe;
        private System.Windows.Forms.Timer tm1;
    }
}