﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyKhoHang.GiaoDien
{
    public partial class fmNCC_TK_KH : Form
    {
        public fmNCC_TK_KH()
        {
            InitializeComponent();
        }

    


    }
}
