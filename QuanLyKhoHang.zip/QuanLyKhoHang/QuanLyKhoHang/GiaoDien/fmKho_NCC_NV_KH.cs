﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyKhoHang.GiaoDien
{
    public partial class fmKhoHang : Form
    {
        private int idQuanLy;
        fmQuanLy fmQuanLy;
        bool isKho = true;
        int coThem=0;
        public fmKhoHang(fmQuanLy fmQuanLy,int idQuanLy)
        {
            InitializeComponent();
            this.idQuanLy = idQuanLy;
            this.fmQuanLy = fmQuanLy;
            Check();
        }


        private void fmKhoHang_Load(object sender, EventArgs e)
        {
            if (idQuanLy == 0)
               if(isKho) BUS.KhoBUS.Instance.loadData(dtgv);
               else { }
            else if(idQuanLy==1)
            {
               BUS.NhaCungCapBUS.Instance.loadData(dtgv);
            }  
            else if(idQuanLy==5)
            {
                BUS.KhachHangBUS.Instance.loadData(dtgv);
            }
        }
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (idQuanLy == 0)
               if (isKho) BUS.KhoBUS.Instance.timKiem(dtgv, txtTimKiem.Text);
               else { }
            else if(idQuanLy==1)
            {
                BUS.NhaCungCapBUS.Instance.TimKiem(dtgv, txtTimKiem.Text);
            }
            else if(idQuanLy==5)
            {
                BUS.KhachHangBUS.Instance.timKiem(dtgv, txtTimKiem.Text);
            }
        }
        

        void Check()
        {
            Point pKho = new Point(21, 59);
            Point pHang = new Point(86, 58);
            Point pPhanQuyen = new Point(17, 393);
            Point p = new Point(-100, -100);
            if (idQuanLy == 0)
            { 
                this.btnHang.Enabled = this.btnKho.Enabled = this.btnPhanQuyen.Enabled = true;
                this.btnHang.BackColor = Color.FromArgb(157, 87, 2);
                this.btnKho.BackColor= Color.FromArgb(254, 141, 0);
                this.btnPhanQuyen.BackColor = Color.FromArgb(97, 58, 151);
                this.btnKho.Location = pKho;
                this.btnHang.Location = pHang;
                this.btnPhanQuyen.Location = pPhanQuyen;
            }
            else
                {
                    this.btnHang.Enabled = this.btnKho.Enabled = this.btnPhanQuyen.Enabled = false;
                    this.btnKho.Location = this.btnHang.Location = this.btnPhanQuyen.Location = p;
                }
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            this.Hide();
            fmQuanLy.Show();
        }

        private void pcbThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnKho_Click(object sender, EventArgs e)
        {
            isKho = true;
        }

        private void btnHang_Click(object sender, EventArgs e)
        {
            isKho = false;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            coThem = 1;
            if(idQuanLy==0)
                          if(isKho) BUS.KhoBUS.Instance.themKho(dtgv);
                          else { }
            else if(idQuanLy==1)
            {
                BUS.NhaCungCapBUS.Instance.Them(dtgv);
            }
            else if(idQuanLy==5)
            {
                BUS.KhachHangBUS.Instance.Them(dtgv);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if(idQuanLy==0)
                if(isKho)
                         BUS.KhoBUS.Instance.xoaKho(dtgv);
                else { }
            else if(idQuanLy==1)
            {
                BUS.NhaCungCapBUS.Instance.Xoa(dtgv);
            }
            else if(idQuanLy==5)
            {
                BUS.KhachHangBUS.Instance.Xoa(dtgv);
            }
        }
        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (idQuanLy == 0)
            {
                if (isKho) if (coThem == 1){ BUS.KhoBUS.Instance.LuuThem(dtgv); coThem = 0;  } else BUS.KhoBUS.Instance.LuuSua(dtgv);
                else
                {

                }
            }
            else if(idQuanLy==1)
            {
                if (coThem == 1)
                {
                    BUS.NhaCungCapBUS.Instance.LuuThem(dtgv);
                    coThem = 0;
                }
                else
                    BUS.NhaCungCapBUS.Instance.LuuSua(dtgv);
            }
            else if(idQuanLy==5)
            {
                if (coThem == 1)
                {
                    BUS.KhachHangBUS.Instance.LuuThem(dtgv);
                    coThem = 0;
                }
                else
                    BUS.KhachHangBUS.Instance.LuuSua(dtgv);
            }
        }
    }
}
