﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyKhoHang.GiaoDien
{
    public partial class fmDangNhap : Form
    {
        fmQuanLy fmQuanLy;
        public fmDangNhap()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            if (BUS.QuanLyNhanVienBUS.Instace.Check(txtTaiKhoan.Text, txtMatKhau.Text) != -1)
            {
                fmQuanLy = new fmQuanLy(this,
                    BUS.QuanLyNhanVienBUS.Instace.Check(txtTaiKhoan.Text, txtMatKhau.Text));
                this.Hide();
                fmQuanLy.Show();
            }
                 
        }
    }
}
