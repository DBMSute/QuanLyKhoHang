﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BUS
{
   public class KhachHangBUS
    {
       private static KhachHangBUS instance;
       public static KhachHangBUS Instance
        {
            get
            {
                if (instance == null) return new KhachHangBUS();
                return instance;
            }
        }
       public  void loadData(DataGridView dgv)
       {
           dgv.DataSource = DAO.KhachHangDAO.Instance.loadData();
       }
       public void timKiem(DataGridView dgv,string str)
       {
           dgv.DataSource = DAO.KhachHangDAO.Instance.timKiem(str.Trim());
       }
       public void Them(DataGridView dgv)
       {
           dgv.DataSource = DAO.KhachHangDAO.Instance.Them();
       }
       public void Xoa(DataGridView dt,string str)
       {
           try
           {
               int index = dt.CurrentCell.RowIndex;
               string id = dt.Rows[index].Cells[0].Value.ToString().Trim();
               DAO.KhachHangDAO.Instance.Xoa(id);
               MessageBox.Show("Xóa thành công !");
           }
           catch
           {
               MessageBox.Show("Không xóa được !");
           }
           timKiem(dt, str);
       }
       public void LuuThem(DataGridView dgv)
       {
           List<DAO.KhachHang> lKh = new List<DAO.KhachHang>();
           try
           {
               foreach (DataGridViewRow dr in dgv.Rows)
               {
                   DAO.KhachHang kh = new DAO.KhachHang(dr.Cells[1].Value.ToString().Trim(), dr.Cells[2].Value.ToString().Trim(),
                       dr.Cells[3].Value.ToString().Trim());
                   lKh.Add(kh);
               }
               DAO.KhachHangDAO.Instance.LuuThem(lKh);
               MessageBox.Show(" Thêm thành công  !");
           }
           catch
           {
               MessageBox.Show("lỗi rồi !");
           }
           loadData(dgv);
       }
       public void LuuSua(DataGridView dgv)
       {
           List<DAO.KhachHang> lKh = new List<DAO.KhachHang>();
           try
           {
               foreach (DataGridViewRow dr in dgv.Rows)
               {
                   DAO.KhachHang kh = new DAO.KhachHang(dr.Cells[0].Value.ToString().Trim(),
                       dr.Cells[1].Value.ToString().Trim(),
                       dr.Cells[2].Value.ToString().Trim(),
                       dr.Cells[3].Value.ToString().Trim());
                   lKh.Add(kh);
               }
               DAO.KhachHangDAO.Instance.LuuSua(lKh);
               MessageBox.Show(" Sửa thành công  !");
           }
           catch
           {
               MessageBox.Show("lỗi rồi !");
           }
           loadData(dgv);
       }
    }
}
