﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
   public class KhoBUS
    {
       private static KhoBUS instance;
       public static KhoBUS Instace
        {
            get
            {
                if (instance == null) return new KhoBUS();
                return instance;
            }
        }
    }
}
