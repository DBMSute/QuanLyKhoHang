﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace BUS
{
   public class KhoBUS
    {
       private static KhoBUS instance;
       int index;
       public static KhoBUS Instance
        {
            get
            {
                if (instance == null) return new KhoBUS();
                return instance;
            }
        }
       public void loadData(DataGridView dt)
       {
           dt.DataSource = DAO.KhoDAO.Instance.loadData();
       }
       public void timKiem(DataGridView dt,string strTimKiem)
       {
           dt.DataSource = DAO.KhoDAO.Instance.timKiem(strTimKiem.Trim());
       }
       public void LuuThem(DataGridView dgv)
       {
              List<DAO.Kho> lKho = new List<DAO.Kho>();
               try
               {
                   foreach (DataGridViewRow dr in dgv.Rows)
                   {
                       DAO.Kho k = new DAO.Kho(dr.Cells[1].Value.ToString().Trim(), dr.Cells[2].Value.ToString().Trim(), dr.Cells[3].Value.ToString().Trim()
                           , (bool)dr.Cells[4].Value);
                       lKho.Add(k);
                   }
                   DAO.KhoDAO.Instance.LuuThem(lKho);
                   MessageBox.Show(" Thêm thành công  !");
               }
               catch
               {
                   MessageBox.Show("lỗi rồi !");
               }
               loadData(dgv);
       }
       public void LuuSua(DataGridView dgv)
       {
           List<DAO.Kho> lKho = new List<DAO.Kho>();
           try
           {
               foreach (DataGridViewRow dr in dgv.Rows)
               {
                   DAO.Kho k = new DAO.Kho(dr.Cells[0].Value.ToString().Trim(),
                       dr.Cells[1].Value.ToString().Trim(),
                       dr.Cells[2].Value.ToString().Trim(),
                       dr.Cells[3].Value.ToString().Trim()
                       , (bool)dr.Cells[4].Value);
                   lKho.Add(k);
               }
               DAO.KhoDAO.Instance.LuuSua(lKho);
               MessageBox.Show(" Sửa thành công  !");
           }
           catch
           {
               MessageBox.Show("lỗi rồi !");
           }
           loadData(dgv);
       }
       public void themKho(DataGridView dt)
       {
           dt.DataSource = DAO.KhoDAO.Instance.themKho();
       }
       public void xoaKho(DataGridView dt,string str)
       {
           try {
            index = dt.CurrentCell.RowIndex;
            string id = dt.Rows[index].Cells[0].Value.ToString().Trim();
            DAO.KhoDAO.Instance.xoaKho(id);
            MessageBox.Show("Xóa thành công !");
           }
           catch
           {
               MessageBox.Show("Không xóa được !");
           }
           timKiem(dt, str);
       }
    }
}
