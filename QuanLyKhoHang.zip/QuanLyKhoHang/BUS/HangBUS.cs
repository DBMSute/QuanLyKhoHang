﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUS
{
  public  class HangBUS
    {
        private static KhoBUS instance;
        public static KhoBUS Instance
        {
            get
            {
                if (instance == null) return new KhoBUS();
                return instance;
            }
        }
      //  public List<DTO.SanPham> loadData()
     //   {

      //  }
      public void Them()
      {

      }
      public void LuuThem()
      {

      }
      public void LuuSua()
      {

      }
      public void Sua()
      {

      }
  }
}
