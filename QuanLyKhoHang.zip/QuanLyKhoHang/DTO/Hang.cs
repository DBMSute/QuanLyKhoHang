﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
   public class Hang
    {
       public int id, idKho;
       public string ten;
       public Hang(int id,string ten,int idKho)
       {
           this.id = id;
           this.ten = ten;
           this.idKho = idKho;
       }
     
       public int ID
       {
           get { return id; }
           set { id = value; }
       }
       public int IDKHO
       {
           get { return idKho; }
           set { idKho = value; }
       }
       public string TEN
       {
           get { return ten; }
           set { ten = value; }
       }
     
    }
}
