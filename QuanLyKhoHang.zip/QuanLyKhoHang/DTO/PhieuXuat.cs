﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class PhieuXuat
    {
        public string thoiGian;
        public int id;
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public string THOIGIAN
        {
            get { return thoiGian; }
            set { thoiGian= value; }
        }
      
        public PhieuXuat(int id,string thoiGian)
        {
            this.id = id;
            this.thoiGian = thoiGian;
            
        }
    }
}
