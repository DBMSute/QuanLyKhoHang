﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class SanPham
    {
        public string id, ten, idLoai, idKho, donViTinh;
        public float donGia;
        public bool tinhTrang;
        public string ID
        {
            get { return id; }
            set { id = value; }
        }
        public string TEN
        {
            get { return ten; }
            set { ten = value; }
        }
        public string IDLoai
        {
            get { return idLoai; }
            set { idLoai = value; }
        }
        public string IDKho
        {
            get { return idKho; }
            set { idKho = value; }
        }
        public string DONVITINH
        {
            get { return donViTinh; }
            set { donViTinh = value; }
        }
        public float DONGIA
        {
            get { return donGia; }
            set { donGia = value; }
        }
        public bool TINHTRANG
        {
            get { return tinhTrang; }
            set { tinhTrang = value; }
        }
        public SanPham(string id,string ten,string idLoai,string idKho,string donViTinh
            ,float donGia,bool tinhTrang)
        {
            this.id = id;
            this.ten = ten;
            this.idLoai = idLoai;
            this.idKho = idKho;
            this.donViTinh = donViTinh;
            this.donGia = donGia;
            this.tinhTrang = tinhTrang;
        }
    }
}
