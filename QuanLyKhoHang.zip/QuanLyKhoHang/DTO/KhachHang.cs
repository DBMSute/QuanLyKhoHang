﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class KhachHang
    {
        public int id;
        public string ten, soDT, diaChi;
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public string TEN
        {
            get { return ten; }
            set { ten = value; }
        }
        public string SODT
        {
            get { return soDT; }
            set { soDT = value; }
        }
        public string DIACHI
        {
            get { return diaChi; }
            set { diaChi = value; }
        }
        public KhachHang(int id,string ten,string soDT,string diaChi)
        {
            this.id = id;
            this.ten = ten;
            this.soDT = soDT;
            this.diaChi = diaChi;
        }
    }
}
