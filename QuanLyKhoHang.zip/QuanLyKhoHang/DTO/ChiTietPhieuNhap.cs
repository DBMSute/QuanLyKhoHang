﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
   public class ChiTietPhieuNhap
    {
        public int idPhieuNhap, idHang, idNCC, soLuong;
        public float donGia;
        public string donviTien;
       public int IDPHIEUNHAP
       {
           get { return idPhieuNhap; }
           set { idPhieuNhap = value; }
       }
       public int IDHANG
       {
           get { return idHang; }
           set { idHang = value; }
       }
       public int IDNCC
       {
           get { return idNCC; }
           set { idNCC = value; }
       }
       public float DONGIA
       {
           get { return donGia; }
           set { donGia = value; }
       }
       public int SOLUONG
       {
           get { return soLuong; }
           set { soLuong = value; }
       }
      
       public ChiTietPhieuNhap(int idPhieuNhap,int idHang,int idNCC,int soLuong,
    float donGia,
         string donviTien)
       {
           this.idPhieuNhap = idPhieuNhap;
           this.idHang = idHang;
           this.idNCC = idNCC;
           this.donGia = donGia;
           this.soLuong = soLuong;
           this.donviTien = donviTien;
       }
    }
}
