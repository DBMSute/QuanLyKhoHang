﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class ChiTietPhieuXuat
    {
        public int idPhieuXuat, idHang, idKHang, soLuong;
        public float donGia;
        public string donViTien;

        public int IDPHIEUXUAT
        {
            get { return idPhieuXuat; }
            set { idPhieuXuat = value; }
        }
        public int IDHANG
        {
            get { return idHang; }
            set { idHang = value; }
        }
        public int IDKHANG
        {
            get { return idKHang; }
            set { idKHang = value; }
        }
        public int SOLUONG
        {
            get { return soLuong; }
            set { soLuong = value; }
        }
        public string DONVITIEN
        {
            get { return donViTien; }
            set { donViTien = value; }
        }
        public ChiTietPhieuXuat(int idPhieuXuat,int idHang,int idKHang,int soLuong,float donGia
            ,string donViTien)
        {
            this.idPhieuXuat = idPhieuXuat;
            this.idHang = idHang;
            this.soLuong = soLuong;
            this.donGia = donGia;
            this.donViTien = donViTien;
        }
    }
}
