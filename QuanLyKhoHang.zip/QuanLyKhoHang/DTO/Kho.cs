﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
   public class Kho
    {
       public int id;
       public string ten, diaChi;
       bool tinhTrang;
       public int ID
       {
           get { return id; }
           set { id = value; }
       }
       public string TEN
       {
           get { return ten; }
           set { ten = value; }
       }
       public string DIACHI
       {
           get { return diaChi; }
           set { diaChi = value; }

       }
       public bool TINHTRANG
       {
           get { return tinhTrang; }
           set { tinhTrang = value; }
       }
       public Kho(int id,string ten,string diaChi,bool tinhTrang)
       {
           this.id = id;
           this.ten = ten;
           this.diaChi = diaChi;
           this.tinhTrang = tinhTrang;
       }
    }
}
